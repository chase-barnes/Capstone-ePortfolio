#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun  6 21:33:00 2025

@author: chasebarnes2_snhu
"""

from pymongo import MongoClient, ASCENDING, DESCENDING
from urllib.parse import quote_plus
import os, time

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        # USER = quote_plus(username) #aacuser
        # PASS = quote_plus(password) #Mercuryaac@1254
        HOST = 'localhost'
        PORT = 27017
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%d' % (HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        self._cache ={} # simple in-process cache data structure
        return 

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            response = self.database.animals.insert_one(data)  # data should be dictionary
            return True if response.acknowledged else False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Create method to implement the R in CRUD.
    def read(self, query={}):
        return list(self.database.animals.find(query))

                                                                                                                                                       
    # Method to implement the U in CRUD.
    def update(self, query, data):
        if query and data is not None:
            response = self.database.animals.update_many(query, {"$set": data})
            return response.modified_count
        else:
            raise Exception("Nothing to update, because data or query parameter is empty")    
    
    # Method to implement the D in CRUD.
    def delete(self, query):
        if query is not None:
            response = self.database.animals.delete_many(query)
            return response.deleted_count
        else: 
            raise Exception("Nothing to delete, becuase query parameter is empty")
        
    def frequent_indexes(self):
        saved_indexes = [] # simple data structure intended to 
        saved_indexes.append(self.database.animals.create_index([("breed", ASCENDING)]))
        saved_indexes.append(self.database.animals.create_index([("outcome_type", ASCENDING)]))
        saved_indexes.append(self.database.animals.create_index([("age_upon_outcome_in_weeks", ASCENDING)]))
        