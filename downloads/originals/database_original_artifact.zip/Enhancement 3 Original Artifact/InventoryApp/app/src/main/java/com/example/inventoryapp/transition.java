package com.example.inventoryapp;

public class transition {
}
