package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;

public class OverviewActivity extends AppCompatActivity {

    //Declare UI variables
    RecyclerView recyclerView;
    FloatingActionButton addItemButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overview);

        //Define variables with XML UI elements
        recyclerView = findViewById(R.id.inventoryRecyclerView);
        addItemButton = findViewById(R.id.addItemButton);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
    }

    public void addItem(View view) {
        startActivity(new Intent(this, AddItemActivity.class));
    }
}
