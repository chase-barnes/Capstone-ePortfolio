package com.example.inventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ItemDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "item.db";
    private static final int VERSION = 1;

    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "item name";
        private static final String COL_QUANTITY = "item quantity";
    }

    /**
     *
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL("create table " + ItemDatabase.ItemTable.TABLE + " (" +
//                ItemDatabase.ItemTable.COL_ID + " integer primary key autoincrement, " +
//                ItemDatabase.ItemTable.COL_NAME + " text, " +
//                ItemDatabase.ItemTable.COL_QUANTITY + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + ItemDatabase.ItemTable.TABLE);
        onCreate(db);
    }

    /**
     *
     * @param name
     * @param quantity
     */
//    public boolean addItem(String name, int quantity) {
//
//    }
//
//    public boolean updateItemQuantity(String name, int quantity) {
//
//    }
//
//    public boolean deleteItem(String name) {
//
//    }

    /**
     * This method is tasked with retrieving every entry from the database
     * @return database contents
     */
//    public Cursor getAllItems() {
//        SQLiteDatabase db = this.getReadableDatabase();
//        return db.rawQuery("SELECT * FROM " + ItemTable, null);
//    }
}

