package com.example.inventoryapp;

public class InventoryItem {
    private String itemName;
    private int itemStock;

    public InventoryItem(String name, int stock) {
        this.itemName = name;
        this.itemStock = stock;
    }

    public String getItemName() {
        return itemName;
    }

    public int getItemStock() {
        return itemStock;
    }
}
