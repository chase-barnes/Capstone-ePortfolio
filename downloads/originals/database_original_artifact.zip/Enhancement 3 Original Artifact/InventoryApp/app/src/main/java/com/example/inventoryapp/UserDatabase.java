package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This class is tasked with storing user credentials
 */
public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "user.db";
    private static final int VERSION = 1;

    /**
     * Constructor
     * @param context
     */
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * This class defines the collection and fields of the user db
     */
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    /**
     * This method is tasked with handling the creation of the database entity
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text)");
    }

    /**
     * This method is tasked with handling an update to the database entity
     * @param db The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    /**
     * This method is tasked with registering new user credentials in the user collection
     * @param username
     * @param password
     * @return user credentials
     */
    public long registerUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);

        long userID = db.insert(UserTable.TABLE, null, values);
        return userID;
    }

    /**
     * This method is tasked with retrieving user credentials for authentication
     * @param username
     * @param password
     * @return validation success status
     */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE + " where username = ? AND password=?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});
        if(cursor.moveToFirst()) {
            do {
                return true;
            } while (cursor.moveToNext());

        }
        cursor.close();
        return false;
    }
}
