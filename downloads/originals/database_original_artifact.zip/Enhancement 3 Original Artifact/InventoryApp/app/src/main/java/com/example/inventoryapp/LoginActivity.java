package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Button loginBtn;
    Button registerBtn;
    UserDatabase db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.usernameText);
        password = findViewById(R.id.passwordText);
        loginBtn = findViewById(R.id.loginButton);
        registerBtn = findViewById(R.id.registerButton);
        db = new UserDatabase(this);
    }

    public void loginAttempt() {
        if(db.validateUser(username.getText().toString(), password.getText().toString())){
            startActivity(new Intent(LoginActivity.this, OverviewActivity.class));
        } else {
            Toast.makeText(this, "INVALID CREDENTIALS", Toast.LENGTH_SHORT).show();
        }
    }

    public void registerUser() {
        db.registerUser(username.getText().toString(), password.getText().toString());
        startActivity(new Intent(LoginActivity.this, OverviewActivity.class));
    }


}
