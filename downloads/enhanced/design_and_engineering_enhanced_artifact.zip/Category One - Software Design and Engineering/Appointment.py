from datetime import datetime

'''
A simple class to hold information about an appointment

Note that there is no mutators defined for id so this value cannot be changed once a task is created

Author: chase.barnes2@snhu.edu
'''
class Appointment:

    '''
    Constructor

    :param id          - Unique identifier for a task
    :param date        - Appoitnemnt date
    :param description - Task's description
    '''
    def __init__(self, id: str, date: datetime, description: str):
        if id is None or len(id) > 10:
            raise ValueError("Invalid id value")
        self._id = id
        self._date = None
        self._description = None
        self.set_date(date)
        self.set_description(description)

    '''
    Accessor for id value
    
    return the task id
    '''
    @property
    def id(self):
        """Read-only property for id."""
        return self._id

    '''
    Accessor for date value
    
    return the appointment date
    '''
    @property
    def date(self):
        return self._date

    '''
    Mutator for date value

    :param date - Appointment date
    :exception illegalArgumentException - in the case date value is null or is before today's date
    '''
    def set_date(self, date: datetime):
        if date is None or date < datetime.now():
            raise ValueError("Invalid date value")
        self._date = date

    '''
    Accessor for description value
    
    return additional info about task
    '''
    @property
    def description(self):
        return self._description

    '''
    Mutator for description value

    :param description - Task's description
    :exception illegalArgumentException - in the case description value is null or longer than 50 characters
    '''
    def set_description(self, description: str):
        if description is None or len(description) > 50:
            raise ValueError("Invalid description value")
        self._description = description

    def __str__(self):
        return f"Appointment [id={self._id}, date={self._date}, description={self._description}]\n"