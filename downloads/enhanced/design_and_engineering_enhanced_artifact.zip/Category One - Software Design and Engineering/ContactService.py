from Contact import Contact
from typing import List

'''
A service for managing stored contacts

Functionality includes adding, deleting, and updating contact information in
a locally defined data structure. Notice the overloaded constructor that
requires a list of contact objects to be passed when creating. This is
specified for JUnit tests, but may not be included in later implementations.
 
Author: chase.barnes2@snhu.edu
'''
class ContactService:
    '''
    Default Constructor
    '''
    def __init__(self):
        self.contacts: List[Contact] = []

    '''
    Create a new contact and add it to the stored contacts list
	
	:param id        - Unique identifier for a contact
	:param firstName - Contact's first name
	:param lastName  - Contact's last name
	:param phone     - Contact's phone number
	:param address   - Contact's home address
	:exception ValueError - in the case the provided contact id already exists in the stored contacts list
    '''
    def add_contact(self, id: str, first_name: str, last_name: str, phone: str, address: str) -> None:
        for contact in self.contacts:
            if contact._id.lower() == id.lower():
                raise ValueError("Contact ID already exists in stored contacts")
        self.contacts.append(Contact(id, first_name, last_name, phone, address))

    '''
    Delete a contact from the stored contacts list with a correlating id number
	
	:param id - Unique identifier for a contact
	:exception LookupError - in the case the provided id does not have a correlating contact stored in the list
    '''
    def delete_contact(self, id: str) -> None:
        for contact in self.contacts:
            if contact._id.lower() == id.lower():
                self.contacts.remove(contact)
                return
        raise LookupError("Contact id not found in stored contacts")

    '''
    Update a contact's recorded first name by iterating through the contact list and finding the designated contact with the correlating id

	:param id        - Unique identifier for a contact
	:param firstName - Contact's first name
	:exception LookupError - in the case the provided id does not have a correlating contact stored in the list
    '''
    def update_first_name(self, id: str, first_name: str) -> None:
        for contact in self.contacts:
            if contact._id.lower() == id.lower():
                contact._first_name = first_name
                return
        raise LookupError("Contact id not found in stored contacts")

    '''
    Update a contact's recorded last name by iterating through the contact list
	and finding the designated contact with the correlating id
	
	:param id       - Unique identifier for a contact
	:param lastName - Contact's last name
	:exception LookupError - in the case the provided id does not have a correlating contact stored in the list
    '''
    def update_last_name(self, id: str, last_name: str) -> None:
        for contact in self.contacts:
            if contact._id.lower() == id.lower():
                contact._last_name = last_name
                return
        raise LookupError("Contact ID not found in stored contacts")

    '''
     Update a contact's recorded phone number by iterating through the contact
	 list and finding the designated contact with the correlating id
	 
	 :param id    - Unique identifier for a contact
	 :param phone - Contact's phone number
	 :exception LookupError - in the case the provided id does not have a correlating contact stored in the list
    '''
    def update_phone(self, id: str, phone: str) -> None:
        for contact in self.contacts:
            if contact._id.lower() == id.lower():
                contact._phone = phone
                return
        raise LookupError("Contact id not found in stored contacts")

    '''
    Update a contact's recorded address by iterating through the contact list and
	 finding the designated contact with the correlating id
	 
	 :param id      - Unique identifier for a contact
	 :param address - Contact's home address
	 :exception LookupError - in the case the provided id does not have a correlating contact stored in the list
    '''
    def update_address(self, id: str, address: str) -> None:
        for contact in self.contacts:
            if contact._id.lower() == id.lower():
                contact._address = address
                return
        raise LookupError("Contact id not found in stored contacts")

    '''
    Clears the list of contacts. Current implementation utilizes this function to reset the list. May be removed in future implementations
    '''
    def clear_contact_list(self) -> None:
        self.contacts.clear()

    '''
	return a list of all the elements in the contact list
    '''
    def __str__(self) -> str:
        return ''.join(str(contact) for contact in self.contacts)