from Appointment import Appointment
from datetime import datetime
from typing import List

'''
A service for managing stored appointments

Functionality includes adding, deleting, deleting all appointment information in
a locally defined data structure. Notice the overloaded constructor that
requires a list of appointment objects to be passed when creating. This is
specified for JUnit testing, but may not be included in later implementations.

Author: chase.barnes2@snhu.edu
'''
class AppointmentService:
    
    '''
    Default Constructor
    '''
    def __init__(self):
        self.appointments: List[Appointment] = []

    '''
    Create a new appointment and add it to the stored appointment list
    
    :param id          - Unique identifier for a appointment
	:param date        - Appointment date
	:param description - Appointment's description
	:exception IllegalArgumentException - in the case the provided appointment id already exists in the stored appointments list
    '''
    def add_appointment(self, id: str, date: datetime, description: str) -> None:
        for stored_appointment in self.appointments:
            if stored_appointment.id.lower() == id.lower():
                raise ValueError("Appointment id already exists in stored appointments")
        self.appointments.append(Appointment(id, date, description))

    '''
    Delete a appointment from the stored appointments list with a correlating id number
	
	:param id - Unique identifier for a appointment
	:exception NoSuchElementException - in the case the provided id does not have a correlating appointment stored in the list
    '''
    def delete_appointment(self, id: str) -> None:
        for stored_appointment in self.appointments:
            if stored_appointment.id.lower() == id.lower():
                self.appointments.remove(stored_appointment)
                return
        raise LookupError("Appointment id not found in stored appointments")

    '''
    Clears the list of appointments. Current implementation utilizes this function to
	reset the list. May be removed in future implementations
    '''
    def clear_appointment_list(self) -> None:
        self.appointments.clear()

    '''
    return a list of all the elements in the appointment list
    '''
    def __str__(self) -> str:
        return ''.join(str(appointment) for appointment in self.appointments)