'''
A simple class to hold information about a contact

Note that there is no mutator for id so this value cannot be changed once a contact is created.

Author: chase.barnes2@snhu.edu
'''
class Contact:

    '''
    Constructor

    :param id - Unique identifier for a contact
    :param firstName - Contact's first name
    :param lastName - Contact's last name
    :param phone - Contact's phone number
    :param address - Contact's home address
    '''
    def __init__(self, id: str, first_name: str, last_name: str, phone: str, address: str):
        if id is None or len(id) > 10:
            raise ValueError("Invalid id value")
        self._id = id
        self.set_first_name(first_name)
        self.set_last_name(last_name)
        self.set_phone(phone)
        self.set_address(address)

    '''
    Accessor for id value
    
    return the contact id
    '''
    def get_id(self) -> str:
        """Accessor for id"""
        return self._id

    '''
    Accessor for first name value
    
    return the contact's first name
    '''
    def get_first_name(self) -> str:
        return self._first_name

    '''
    Mutator for first name value
    
    :param firstName - Contact's first name
    :exception illegalArgumentException - in the case first name value is null or longer than 10 characters'''
    def set_first_name(self, first_name: str):
        if first_name is None or len(first_name) > 10:
            raise ValueError("Invalid first name value")
        self._first_name = first_name

    '''
    Accessor for last name value
    
    return the contact's last name
    '''
    def get_last_name(self) -> str:
        return self._last_name

    '''
    Mutator for last name value
    
    :param lastName - Contact's last name
	:exception illegalArgumentException - in the case last name value is null or longer than 10 characters
    '''
    def set_last_name(self, last_name: str):
        if last_name is None or len(last_name) > 10:
            raise ValueError("Invalid last name value")
        self._last_name = last_name

    '''
    Accessor for phone value
    
    return the contact's phone number
    '''
    def get_phone(self) -> str:
        return self._phone

    '''
    Mutator for phone value
    
    :param phone - Contact's phone number
	:exception illegalArgumentException - in the case phone value is null or greater than/less than 10 characters
    '''
    def set_phone(self, phone: str):
        if phone is None or len(phone) != 10:
            raise ValueError("Invalid phone value")
        self._phone = phone

    '''
    Accessor for address value
    
    return the contact's home address
    '''
    def get_address(self) -> str:
        return self._address

    '''
    Mutator for address value

	:param address - Contact's home address
	:exception illegalArgumentException - in the case address value is null or longer than 30 characters
    '''
    def set_address(self, address: str):
        if address is None or len(address) > 30:
            raise ValueError("Invalid address value")
        self._address = address

    def __str__(self) -> str:
        return f"Contact [id={self._id}, firstName={self._first_name}, lastName={self._last_name}, phone={self._phone}, address={self._address}]\n"