from Task import Task
from typing import List

'''
A service for managing stored tasks

Functionality includes adding, deleting, and updating task information in
a locally defined data structure. Notice the overloaded constructor that
requires a list of task objects to be passed when creating. This is
specified for JUnit testing, but may not be included in later implementations.

Author: chase.barnes2@snhu.edu
'''
class TaskService:
    '''
    Default Constructor
    '''
    def __init__(self):
        self.tasks: List[Task] = []
    
    '''
    Create a new task and add it to the stored task list
    
    :param id          - Unique identifier for a task
	:param name        - Title of task
	:param description - Task's description
	:exception ValueError - in the case the provided task id already exists in the stored tasks list
    '''
    def add_task(self, id: str, name: str, description: str) -> None:
        for task in self.tasks:
            if task._id.lower() == id.lower():
                raise ValueError("Task id already exists in stored tasks")
        self.tasks.append(Task(id, name, description))

    '''
    Delete a task ffrom the stored tasks list with a correlating id number
    
    :param id - Unique identifier for a task
	:exception LookupError - in the case the provided id does not have a correlating task stored in the list
    '''
    def delete_task(self, id: str) -> None:
        for task in self.tasks:
            if task._id.lower() == id.lower():
                self.tasks.remove(task)
                return
        raise LookupError("Task id not found in stored tasks")

    '''
    Update a task's recorded name by iterating through the task list and finding
	the designated task with the correlating id
	
	:param id   - Unique identifier for a task
	:param name - Title of task
	:exception LookupError - in the case the provided id does not have a correlating task stored in the list
    '''
    def update_name(self, id: str, name: str) -> None:
        for task in self.tasks:
            if task._id.lower() == id.lower():
                task._name = name
                return
        raise LookupError("Task id not found in stored tasks")

    '''
    Update a task's recorded description by iterating through the task list and
	finding the designated task with the correlating id
	
	:param id          - Unique identifier for a task
	:param description - Task's description
	:exception LookupError - in the case the provided id does not have a correlating task stored in the list
    '''
    def update_description(self, id: str, description: str) -> None:
        for task in self.tasks:
            if task._id.lower() == id.lower():
                task._description = description
                return
        raise LookupError("Task id not found in stored tasks")

    '''
	Clears the list of tasks. Current implementation utilizes this function to
	reset the list. May be removed in future implementations    
    '''
    def clear_task_list(self) -> None:
        self.tasks.clear()

    '''
    return a list of all the elements in the task list
    '''
    def __str__(self) -> str:
        return ''.join(str(task) for task in self.tasks)