'''
A simple class to hold information about a task
 
Note that there is no mutators defined for id so this value cannot be changed once a task is created.
 
Author: chase.barnes2@snhu.edu
'''
class Task:

    '''
    Consrtructor
    
    :param id - Unique identifier for a task
	:param name - Title of task
	:pparam description - Task's description
    '''
    def __init__(self, id: str, name: str, description: str):
        if id is None or len(id) > 10:
            raise ValueError("Invalid id value")
        self._id = id
        self.set_name(name)
        self.set_description(description)

    '''
    Accessor for id value
	 
	return the task id
    '''
    def get_id(self) -> str:
        return self._id

    '''
    Accessor for name value
	
	return the title of the task    
    '''
    def get_name(self) -> str:
        return self._name

    '''
    Mutator for name value
	
	:param name - Title of task
	:exception illegalArgumentException - in the case name value is null or longer than 20 characters
    '''
    def set_name(self, name: str):
        if name is None or len(name) > 20:
            raise ValueError("Invalid first name value")
        self._name = name

    '''
    Accessor for description value
	
	return additional info about task
    '''
    def get_description(self) -> str:
        return self._description

    '''
    Mutator for description value
	
	:param description - Task's description
	:exception illegalArgumentException - in the case description value is null or longer than 50 characters
    '''
    def set_description(self, description: str):
        if description is None or len(description) > 50:
            raise ValueError("Invalid last name value")
        self._description = description

    def __str__(self) -> str:
        return f"Task [id={self._id}, name={self._name}, description={self._description}]\n"