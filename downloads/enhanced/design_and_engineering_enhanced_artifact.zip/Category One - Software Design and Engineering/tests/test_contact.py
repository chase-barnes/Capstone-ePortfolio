import pytest
from Contact import Contact

def test_contact_creation():
    contact = Contact("102", "Chase", "Barnes", "2147643559", "123 Factory Ln.")
    assert contact._id == "102"
    assert contact._first_name == "Chase"
    assert contact._last_name == "Barnes"
    assert contact._phone == "2147643559"
    assert contact._address == "123 Factory Ln."
    assert str(contact).lower() == (
        "contact [id=102, firstName=Chase, lastName=Barnes, phone=2147643559, address=123 Factory Ln.]\n".lower()
    )

'''
The following test is no longer applicable due to python's behavior. 
The appointment class object no longer accepts null values.
If the object wasn't defined more strictly, the null value test would be as follows.

def test_null_values():
    with pytest.raises(ValueError):
        Contact(None, "Chase", "Barnes", "2147643559", "123 Factory Ln.")
    with pytest.raises(ValueError):
        Contact("102", None, "Barnes", "2147643559", "123 Factory Ln.")
    with pytest.raises(ValueError):
        Contact("102", "Chase", None, "2147643559", "123 Factory Ln.")
    with pytest.raises(ValueError):
        Contact("102", "Chase", "Barnes", None, "123 Factory Ln.")
    with pytest.raises(ValueError):
        Contact("102", "Chase", "Barnes", "2147643559", None)
'''



def test_too_long_values():
    with pytest.raises(ValueError):
        Contact("10293847562", "Chase", "Barnes", "2147643559", "123 Factory Ln.")  # ID > 10 chars
    with pytest.raises(ValueError):
        Contact("102", "Bartholomew", "Barnes", "2147643559", "123 Factory Ln.")  # First name > 10
    with pytest.raises(ValueError):
        Contact("102", "Chase", "Bartholomew", "2147643559", "123 Factory Ln.")  # Last name > 10
    with pytest.raises(ValueError):
        Contact("102", "Chase", "Barnes", "12147643559", "123 Factory Ln.")  # Phone > 10 digits
    with pytest.raises(ValueError):
        Contact("102", "Chase", "Barnes", "2147643559", "123 Factory Lane, Kansas City, Missouri")  # Address > 30


def test_too_short_phone_number():
    with pytest.raises(ValueError):
        Contact("102", "Chase", "Barnes", "214764355", "123 Factory Ln.")  # Phone < 10 digits