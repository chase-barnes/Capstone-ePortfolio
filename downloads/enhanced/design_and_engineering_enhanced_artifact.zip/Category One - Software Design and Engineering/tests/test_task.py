import pytest
from Task import Task

def test_task_creation():
    task = Task("102", "Task #1", "The first task")
    assert task._id == "102"
    assert task._name == "Task #1"
    assert task._description == "The first task"
    assert str(task) == "Task [id=102, name=Task #1, description=The first task]\n"
'''
The following test is no longer applicable due to python's behavior. 
The appointment class object no longer accepts null values.
If the object wasn't defined more strictly, the null value test would be as follows.

def test_null_values():
    with pytest.raises(ValueError):
        Task(None, "Task #1", "The first task")
    with pytest.raises(ValueError):
        Task("102", None, "The first task")
    with pytest.raises(ValueError):
        Task("102", "Task #1", None)
'''


def test_too_long_values():
    with pytest.raises(ValueError):
        Task("10293847562", "Task #1", "The first Task")
    with pytest.raises(ValueError):
        Task("102", "Designated First Task", "The first Task")
    with pytest.raises(ValueError):
        Task("102", "Task #1", "This task designated the first portion of work that will be implemented in the first increment")