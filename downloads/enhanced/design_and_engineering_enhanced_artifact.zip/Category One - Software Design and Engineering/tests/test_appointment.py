import pytest
from datetime import datetime, timedelta
from Appointment import Appointment

# Setup test dates
VALID_DATE = datetime.now() + timedelta(days=1)
INVALID_DATE = datetime.now() - timedelta(days=1)

def test_appointment():
    appointment = Appointment("102", VALID_DATE, "The first task")
    assert appointment.id == "102"
    assert appointment.date == VALID_DATE
    assert appointment.description == "The first task"
    assert str(appointment) == f"Appointment [id=102, date={VALID_DATE}, description=The first task]\n"

'''
The following test is no longer applicable due to python's behavior. 
The appointment class object no longer accepts null values.
If the object wasn't defined more strictly, the null value test would be as follows.

def test_null_values():
    with pytest.raises(ValueError):
        Appointment(None, VALID_DATE, "The first task")
    with pytest.raises(ValueError):
        Appointment("102", None, "The first task")
    with pytest.raises(ValueError):
        Appointment("102", VALID_DATE, None)
'''


def test_too_long_values():
    #id too long
    with pytest.raises(ValueError):
        Appointment("10293847562", VALID_DATE, "The first Task")
    #description too long
    with pytest.raises(ValueError):
        Appointment("102", VALID_DATE,
                    "This task designated the first portion of work that will be implemented in the first increment")


def test_value_before_date():
    with pytest.raises(ValueError):
        Appointment("10293847562", INVALID_DATE, "The first Task")