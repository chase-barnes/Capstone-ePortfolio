import pytest
from datetime import datetime, timedelta
from AppointmentService import AppointmentService

VALID_DATE = datetime.now() + timedelta(days=1)

'''
Fixture acts as a before each annotation in java when invoked by each test accordingly
'''
@pytest.fixture
def appointment_service():
    service = AppointmentService()
    service.add_appointment("202", VALID_DATE, "The first appointment")
    service.add_appointment("302", VALID_DATE, "The second appointment")
    yield service # Denotes the seperation of the setup from the teardown in the pytest fixture logic
    service.clear_appointment_list()


def test_add_appointment(appointment_service):
    appointment_service.add_appointment("102", VALID_DATE, "The third appointment")
    expected_output = (
        f"Appointment [id=202, date={VALID_DATE}, description=The first appointment]\n"
        f"Appointment [id=302, date={VALID_DATE}, description=The second appointment]\n"
        f"Appointment [id=102, date={VALID_DATE}, description=The third appointment]\n"
    )
    assert appointment_service.__str__() == expected_output

def test_add_invalid_appointment_duplicate_id(appointment_service):
    with pytest.raises(ValueError) as excinfo:
        appointment_service.add_appointment("302", VALID_DATE, "The third appointment")
    assert "Appointment id already exists" in str(excinfo.value)

def test_delete_appointment(appointment_service):
    appointment_service.delete_appointment("302")
    expected_output = (
        f"Appointment [id=202, date={VALID_DATE}, description=The first appointment]\n"
    )
    assert appointment_service.__str__().lower() == expected_output.lower()

def test_delete_invalid_appointment(appointment_service):
    with pytest.raises(LookupError) as excinfo:
        appointment_service.delete_appointment("102")
    assert "Appointment id not found in stored appointments" in str(excinfo.value)