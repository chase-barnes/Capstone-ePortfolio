import pytest
from TaskService import TaskService

'''
Fixture acts as a before each annotation in java when invoked by each test accordingly
'''
@pytest.fixture
def task_service():
    service = TaskService()
    service.add_task("202", "Task #1", "The first task")
    service.add_task("302", "Task #2", "The second task")
    yield service # Denotes the seperation of the setup from the teardown in the pytest fixture logic
    service.clear_task_list()


def test_add_task(task_service):
    task_service.add_task("102", "Task #3", "The third task")
    expected_output = (
        "Task [id=202, name=Task #1, description=The first task]\n"
        "Task [id=302, name=Task #2, description=The second task]\n"
        "Task [id=102, name=Task #3, description=The third task]\n"
    )
    assert task_service.__str__() == expected_output


def test_add_invalid_task_duplicate_id(task_service):
    with pytest.raises(ValueError):
        task_service.add_task("302", "Task #3", "The third task")


def test_delete_task(task_service):
    task_service.delete_task("302")
    expected_output = "Task [id=202, name=Task #1, description=The first task]\n"
    assert task_service.__str__().lower() == expected_output.lower()


def test_delete_invalid_task(task_service):
    with pytest.raises(LookupError):
        task_service.delete_task("102")


def test_update_task_values(task_service):
    task_service.update_name("202", "Task #3")
    expected_output = (
        "Task [id=202, name=Task #3, description=The first task]\n"
        "Task [id=302, name=Task #2, description=The second task]\n"
    )
    assert task_service.__str__().lower() == expected_output.lower()

    task_service.update_description("202", "The third task")
    expected_output = (
        "Task [id=202, name=Task #3, description=The third task]\n"
        "Task [id=302, name=Task #2, description=The second task]\n"
    )
    assert task_service.__str__().lower() == expected_output.lower()


def test_update_invalid_task_values(task_service):
    with pytest.raises(LookupError):
        task_service.update_name("102", "Task #4")
    with pytest.raises(LookupError):
        task_service.update_description("102", "The fourth task")