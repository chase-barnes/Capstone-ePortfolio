import pytest
from ContactService import ContactService

'''
Fixture acts as a before each annotation in java when invoked by each test accordingly
'''
@pytest.fixture
def contact_service():
    service = ContactService()
    service.add_contact("202", "First", "Last", "9727643559", "345 Industry St.")
    service.add_contact("302", "Benny", "Charles", "3247643559", "567 Corporate Rd.")
    yield service # Denotes the seperation of the setup from the teardown in the pytest fixture logic
    service.clear_contact_list()


def test_add_contact(contact_service):
    contact_service.add_contact("102", "Chase", "Barnes", "2147643559", "123 Factory Ln.")
    expected_output = (
        "Contact [id=202, firstName=First, lastName=Last, phone=9727643559, address=345 Industry St.]\n"
        "Contact [id=302, firstName=Benny, lastName=Charles, phone=3247643559, address=567 Corporate Rd.]\n"
        "Contact [id=102, firstName=Chase, lastName=Barnes, phone=2147643559, address=123 Factory Ln.]\n"
    )
    assert contact_service.__str__().lower() == expected_output.lower()


def test_add_invalid_contact_duplicate_id(contact_service):
    with pytest.raises(ValueError):
        contact_service.add_contact("302", "Benny", "Charles", "3247643559", "567 Corporate Rd.")


def test_delete_contact(contact_service):
    contact_service.delete_contact("302")
    expected_output = (
        "Contact [id=202, firstName=First, lastName=Last, phone=9727643559, address=345 Industry St.]\n"
    )
    assert contact_service.__str__().lower() == expected_output.lower()


def test_delete_invalid_contact(contact_service):
    with pytest.raises(LookupError):
        contact_service.delete_contact("102")


def test_update_values(contact_service):
    contact_service.update_first_name("202", "Chase")
    assert "firstName=Chase" in contact_service.__str__()
    contact_service.update_last_name("202", "Barnes")
    assert "lastName=Barnes" in contact_service.__str__()
    contact_service.update_phone("202", "2147643559")
    assert "phone=2147643559" in contact_service.__str__()
    contact_service.update_address("202", "123 Factory Ln.")
    assert "address=123 Factory Ln." in contact_service.__str__()


def test_update_invalid_values(contact_service):
    with pytest.raises(LookupError):
        contact_service.update_first_name("102", "Chase")
    with pytest.raises(LookupError):
        contact_service.update_last_name("102", "Barnes")
    with pytest.raises(LookupError):
        contact_service.update_phone("102", "2147643559")
    with pytest.raises(LookupError):
        contact_service.update_address("102", "123 Factory Ln.")