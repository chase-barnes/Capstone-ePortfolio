package com.example.teli.data;

import com.example.teli.model.ShowListResponse;
import com.example.teli.model.TvShow;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Define HTTP endpoints the application utilizes
 *
 * Note: Retrofit configures base URL path along with additional implementation
 */
public interface ApiService {

    /**
     * Retrieves a page of shows
     * @param q
     * @param page
     * @param pageSize
     *
     * @return ShowListResponse
     */
    @GET("api/shows")
    Call<ShowListResponse> getShows(
            @Query("q") String q,
            @Query("page") Integer page,
            @Query("pageSize") Integer pageSize
    );

    /**
     * Retrieve a show based on id index
     * @param tvmazeId
     * @return TvShow
     */
    @GET("api/shows/{id}")
    Call<TvShow> getShow(@Path("id") int tvmazeId);
}