require('dotenv').config(); // loads environment variables from .env file
const express = require('express');
const mongoose = require('mongoose');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// Attempt establish connection with Mongo (mongodb://127.0.0.1:27017/tvdb)
const MONGO_URL = process.env.MONGO_URL;
mongoose.connect(MONGO_URL)
    .then(() => console.log('[mongo] connected:', MONGO_URL))
    .catch(error => { 
        console.error('[mongo] error:', err); 
        process.exit(1);
    }
);

// Model defining indexes for document stored in shows collection
const showSchema = new mongoose.Schema({
    tvmazeId: {type: Number, index: true, unique: true},
    name: String,
    image: {medium: String, original: String },
    genres: [String],
    summary: String,
    rating: { average: Number }
}, { collection: 'shows'});

const Show = mongoose.model('Show', showSchema);

showSchema.index({ tvmazeId: 1 }, { unique: true });
showSchema.index({ name: 'text' });

// Health check
app.get('/health', async (_req, res) => {
  try {
    const ping = await mongoose.connection.db.admin().command({ ping: 1 });
    res.json({ ok: 1, ping, time: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ ok: 0, error: e.message });
  }
});

/**
 * Retrieves documents according to map format by providing key term
 */
app.post('/seed', async(req, res) => {
    try {
        const q = (req.query.q || '').trim();
        if (!q) return res.status(400).json({error: 'Missing ?q=searchTerm'});

        const resp = await fetch(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(q)}`);
        if (!resp.ok) 
            throw new Error('TVmaze error: ${resp.status}');
        const data = await resp.json();

        // format of documents retrieved
        const docs = data.map(({ show }) => ({
            tvmazeId: show.id,
            name: show.name,
            image: show.image || {},
            genres: show.genres || [],
            summary: show.summary || '',
            rating: { average: show.rating?.average ?? null }
        }));

        const ops = docs.map(d => ({
            updateOne: { filter: { tvmazeId: d.tvmazeId }, update: { $set: d }, upsert: true }
        }));
        if (ops.length) await Show.bulkWrite(ops, { ordered: false});

        res.json({ query: q, insertedOrUpdated: ops.length});

    } catch (e) {
        console.error('[seed] error', e);
        res.status(500).json({ error: e.message });
    }
});

/**
 * endpoint to rerieve list of shows
 */
app.get('/api/shows', async (req, res) => {
    const q = req.query.q?.trim();
    const page = Math.max(1, parseInt(req.query.page || '1', 10));
    const pageSize = Math.max(1, Math.min(parseInt(req.query.pageSize || '24', 10), 100));
    
    const filter = q ? { name: { $regex: q, $options: 'i' } } : {};
    const cursor = Show.find(filter)
        .sort({ 'rating.average': -1, name: 1 })
        .skip((page - 1) * pageSize)
        .limit(pageSize);

    const [items, total] = await Promise.all([cursor.exec(), Show.countDocuments(filter)]);

    res.json({ items, page, pageSize, total });
});

/**
 * endpoint to retrieve document according to tvmazeId
 */
app.get('/api/shows/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const doc = await Show.findOne({ tvmazeId: id});
    if (!doc) return res.status(404).json({ error: "Not found" });
    res.json(doc);
})

const PORT = process.env.PORT;
app.listen(PORT, () => console.log('[server] http://localhost:#${PORT}'));