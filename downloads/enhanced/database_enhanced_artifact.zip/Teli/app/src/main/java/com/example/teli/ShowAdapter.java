package com.example.teli;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.teli.model.TvShow;
import java.util.ArrayList;
import java.util.List;

/**
 * Loads TvShow objects into item_show activity
 *
 * Note: Database images are loaded into activity utilizing Glide
 */
public class ShowAdapter extends RecyclerView.Adapter<ShowAdapter.VH> {

    // Navigate to show_details activity
    public interface OnClick {
        void open(TvShow show);
    }
    // List of TvShows
    private final List<TvShow> items = new ArrayList<>();
    private final OnClick onClick;

    /**
     * Constructor
     * @param init - list of TV shows
     * @param onClick - Selectable functionality
     */
    public ShowAdapter(List<TvShow> init, OnClick onClick) {
        if (init != null) items.addAll(init);
        this.onClick = onClick;
    }

    /**
     * Load list data on submit
     * @param data - list of TV shows
     */
    public void submit(List<TvShow> data) {
        items.clear();
        if (data != null)
            items.addAll(data);
        notifyDataSetChanged();
    }

    /**
     * Configure view components
     */
    static class VH extends RecyclerView.ViewHolder {
        ImageView poster; TextView title, genres, rating;
        VH(View v) {
            super(v);
            poster = v.findViewById(R.id.posterImage);
            title  = v.findViewById(R.id.titleText);
            genres = v.findViewById(R.id.genresText);
            rating = v.findViewById(R.id.ratingText);
        }
    }

    /**
     * Initiate view for item_show activity
     * @param p   The ViewGroup into which the new View will be added after it is bound to
     *                 an adapter position.
     * @param vt The view type of the new View.
     * @return
     */
    @Override public VH onCreateViewHolder(ViewGroup p, int vt) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_show, p, false);
        return new VH(v);
    }

    /**
     * Bind Show data to item_show view providing show description
     * @param h   The ViewHolder which should be updated to represent the contents of the
     *                 item at the given position in the data set.
     * @param pos The position of the item within the adapter's data set.
     */
    @Override public void onBindViewHolder(VH h, int pos) {
        TvShow s = items.get(pos);
        h.title.setText(s.name);
        h.genres.setText(s.genres != null ? String.join(" • ", s.genres) : "");
        h.rating.setText(s.rating != null && s.rating.average != null ? "★ " + s.rating.average : "★ N/A");
        String url = s.image != null ? (s.image.medium != null ? s.image.medium : s.image.original) : null;
        Glide.with(h.itemView).load(url).into(h.poster);
        h.itemView.setOnClickListener(v -> onClick.open(s));
    }

    /**
     * Retrieve show count
     * @return number of shows
     */
    @Override public int getItemCount() {
        return items.size();
    }
}
