package com.example.teli.model;

import java.util.List;

/**
 * PLain Old Java Object (POJO) that adheres to the JSON structure returned from server
 */
public class TvShow {
    public int tvmazeId; // unique identifier
    public String name; // TV Show Name
    public Image image; // TV Poster image
    public List<String> genres; // List of related genres
    public String summary; // Show detailed summary
    public Rating rating; // Average rating score
    public static class Image {
        public String medium;
        public String original;
    }
    public static class Rating {
        public Double average;
    }
}
