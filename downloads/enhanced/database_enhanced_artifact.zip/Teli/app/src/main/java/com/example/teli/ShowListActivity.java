package com.example.teli;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teli.data.ApiService;
import com.example.teli.data.RetrofitClient;
import com.example.teli.model.ShowListResponse;
import com.example.teli.model.TvShow;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Displays lists of shows using RecyclerView
 */
public class ShowListActivity extends AppCompatActivity {
    private static final String BASE_URL = "http://10.0.2.2:3000/"; // <-- set your backend port
    private RecyclerView rv;
    private ShowAdapter adapter;
    private ApiService api;

    /**
     * ON start initialize functionality
     * @param savedInstanceState
     */
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list); // show_list activity displays list of shows

        rv = findViewById(R.id.showRecyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        // define server adapter
        adapter = new ShowAdapter(new ArrayList<>(), show -> {
            Intent i = new Intent(this, ShowDetailActivity.class);
            i.putExtra("SHOW_ID", show.tvmazeId);
            startActivity(i);
        });
        rv.setAdapter(adapter);

        api = RetrofitClient.create(BASE_URL).create(ApiService.class);
        loadShows(null, 1, 24);
    }

    /**
     * Retrieve data and load into into activity display
     * @param q
     * @param page
     * @param pageSize
     */
    private void loadShows(String q, int page, int pageSize) {
        api.getShows(q, page, pageSize).enqueue(new Callback<ShowListResponse>() {
            @Override public void onResponse(Call<ShowListResponse> call, Response<ShowListResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    adapter.submit(resp.body().items);
                } else {
                    Toast.makeText(ShowListActivity.this, "HTTP " + resp.code(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onFailure(Call<ShowListResponse> call, Throwable t) {
                Toast.makeText(ShowListActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}