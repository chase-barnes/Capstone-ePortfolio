package com.example.teli.model;

import java.util.List;

/**
 * PLain Old Java Object (POJO) that adheres to the JSON structure returned from server
 * for lsit of shows
 */
public class ShowListResponse {
    public List<TvShow> items; // list of TvShow java objects
    public int page; // page of shows
    public int pageSize; // number of shows on page
    public int total; // total shows
}
