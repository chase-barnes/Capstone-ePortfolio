package com.example.teli;

import android.os.Bundle;
import android.text.Spanned;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;
import com.bumptech.glide.Glide;
import com.example.teli.data.ApiService;
import com.example.teli.data.RetrofitClient;
import com.example.teli.model.TvShow;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Displays show details
 */
public class ShowDetailActivity extends AppCompatActivity {
    private ImageView poster; private TextView title, meta, summary;
    private ApiService api;

    /**
     * On start initialize functionality to load selected show data
     * @param savedInstanceState
     */
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_detail);

        poster  = findViewById(R.id.detailPoster);
        title   = findViewById(R.id.detailTitle);
        meta    = findViewById(R.id.detailMeta);
        summary = findViewById(R.id.detailSummary);

        int id = getIntent().getIntExtra("SHOW_ID", -1);
        final String BASE_URL = "http://10.0.2.2:3000/"; // <-- set your actual port
        api = RetrofitClient.create(BASE_URL).create(ApiService.class);

        api.getShow(id).enqueue(new Callback<TvShow>() {
            @Override public void onResponse(Call<TvShow> c, Response<TvShow> r) {
                if (!r.isSuccessful() || r.body()==null) {
                    Toast.makeText(ShowDetailActivity.this, "Not found", Toast.LENGTH_SHORT).show();
                    return;
                }
                TvShow s = r.body();
                title.setText(s.name);
                String rating = (s.rating != null && s.rating.average != null) ? "★ " + s.rating.average : "★ N/A";
                String genres = (s.genres != null) ? String.join(" • ", s.genres) : "";
                meta.setText(rating + (genres.isEmpty() ? "" : "  •  " + genres));
                String img = s.image != null ? (s.image.original != null ? s.image.original : s.image.medium) : null;
                Glide.with(ShowDetailActivity.this).load(img).into(poster);

                // Render TVmaze HTML summary
                Spanned sp = HtmlCompat.fromHtml(s.summary == null ? "" : s.summary, HtmlCompat.FROM_HTML_MODE_COMPACT);
                summary.setText(sp);
            }
            @Override public void onFailure(Call<TvShow> c, Throwable t) {
                Toast.makeText(ShowDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
