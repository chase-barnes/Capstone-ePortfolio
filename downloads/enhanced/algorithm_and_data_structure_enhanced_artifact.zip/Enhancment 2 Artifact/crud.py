#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun  6 21:33:00 2025

@author: chasebarnes2_snhu
"""

from pymongo import MongoClient, ASCENDING
import time

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    # list of filter queries
    RESCUE_FILTERS = {
        # Water Rescue Query
        "Water Rescue": {
            "animal_type": "Dog",
            "breed": {"$in": ["Labrador Retriever", "Labrador Retriever Mix", 
                              "Chesapeake Bay Retriever", "Newfoundland"]},
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
        },
        # Mountain or Wilderness Rescue Query
        "Mountain or Wilderness Rescue": {
            "animal_type": "Dog",
            "breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog",
                              "Siberian Husky", "Rottweiler"]},
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
        },
        # Disaster or Individual Tracking Query
        "Disaster or Individual Tracking": {
            "animal_type": "Dog",
            "breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever",
                              "Bloodhound", "Rottweiler"]},
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}
        }
    }

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        # USER = quote_plus(username) #aacuser
        # PASS = quote_plus(password) #Mercuryaac@1254
        HOST = 'localhost'
        PORT = 27017
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%d' % (HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        self.cache = {} # simple in-process cache data structure
        return 
             

###############################################################
###########     Basic CRUD Logic Implementation     ###########
###############################################################
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            response = self.collection.insert_one(data)  # data should be dictionary
            return True if response.acknowledged else False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Create method to implement the R in CRUD.
    def read(self, query={}):
        return list(self.collection.find(query))
                                                                                                                                             
    # Method to implement the U in CRUD.
    def update(self, query, data):
        if query and data is not None:
            response = self.collection.update_many(query, {"$set": data})
            return response.modified_count
        else:
            raise Exception("Nothing to update, because data or query parameter is empty")    
    
    # Method to implement the D in CRUD.
    def delete(self, query):
        if query is not None:
            response = self.collection.delete_many(query)
            return response.deleted_count
        else: 
            raise Exception("Nothing to delete, because query parameter is empty")
###############################################################


###############################################################
###########      Frequent Index Data Structure      ###########
###############################################################    
    
    """
    Define a data structure that includes frequently utilized indexes to minimize
    computation effort and load time
    
    return: frequently used indexes
    """
    def frequent_indexes(self):
        saved_indexes = [] # simple data structure
        # Compound index (for )
        saved_indexes.append(self.collection.create_index([
            ("animal_type", ASCENDING),
            ("sex_upon_outcome", ASCENDING),
            ("breed", ASCENDING),
            ("age_upon_outcome_in_weeks", ASCENDING)
        ]))
        saved_indexes.append(self.collection.create_index([("breed", ASCENDING)]))
        saved_indexes.append(self.collection.create_index([("outcome_type", ASCENDING)]))
        saved_indexes.append(self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)]))
        saved_indexes.append(self.collection.create_index([("name", ASCENDING)]))
        return saved_indexes
###############################################################


###############################################################
###############      Aggregation Algorithm      ###############
###############################################################  

    """
    Executes an aggregation pipeline on MongoDB server
    
    :param pipeline - list of pipeline stages
    :param limit - max number of results
    
    return: list of aggregated values
    """
    def aggregate(self, pipeline, limit=50):
        if pipeline:
            pipe = list(pipeline)
        else:
            pipe = []
        if limit and limit > 0:
            pipe = pipe + [{"$limit": int(limit)}]
        return list(self.collection.aggregate(pipe, allowDiskUse=True))
###############################################################


###############################################################
###########        Lazy loading (Pagination)      #############
###############################################################
     
    """
     Retrieve number of documents in filter
     
     return: number of documents
     """
    def count(self, query=None):
        return self.collection.count_documents(query or {})  
    
    """
    Paginated read with optional projection and sort (lazy loading)
    :query - document filter
    :projection - fields to retrieve
    :sort - ordering of documents
    :page - page number
    :page_size - size of a page
    
    returns exactly one page of results
    """
    def read_page(self, query=None, projection=None, sort=None, page=1, page_size=15):
        q = query or {}
        p = max(1, int(page))
        n = max(1, min(int(page_size), 1000))
        cur = self.collection.find(q, projection=projection)
        if sort:
            cur = cur.sort(sort)
        cur = cur.skip((p - 1) * n).limit(n)
        return list(cur)
###############################################################


###############################################################
#########     Cached Queries Data Structure/Algo    ###########
###############################################################    
    
    """
    Retrieve recently cached value
    :param key - string key or map value
    :param ttl_s - seconds value persists in memory
    
    return: query if found in cache
    """
    def get_cached(self, key, ttl_s=500):
        now = time.time()
        if key in self.cache:
            exp, val = self.cache[key]
            if now < exp:
                return val
            else:
                del self.cache[key]
        return None
    
    """
    Store a new query value in the cache
    :param key - string key or map value
    :param val - query
    :param ttl_s - seconds value persists in memory
    
    return: saved query value 
    """
    def set_cached(self, key, val, ttl_s=500):
        self.cache[key] = (time.time() + ttl_s, val)
        return val

    """
    Associate and retrieve filter query from list
    :param rescue_type - rescue filter key string
    
    return: filter dict for given rescue type
    """
    def match_rescue(self, rescue_type):
        key = rescue_type.strip()
        if key not in self.RESCUE_FILTERS:
            raise ValueError("Unknown rescue type")
        return dict(self.RESCUE_FILTERS[key])

    """
    Count data per outcome_type for a cached rescue filter
    :param rescue_type - rescue filter key string
    :param ttl_s - seconds value persists in memory
    
    return: found query value in cache or newly created saved query value in cache
    """
    def cached_count_by_outcome_rescue(self, rescue_type, ttl_s= 300):
        key = ("count_by_outcome_rescue", rescue_type)
        cached = self.get_cached(key, ttl_s)
        if cached is not None:
            return cached
        pipeline = [
            {"$match": self.match_rescue(rescue_type)},
            {"$group": {"_id": "$outcome_type", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
        ]
        result = self.aggregate(pipeline, limit=1000)
        return self.set_cached(key, result, ttl_s)
    
###############################################################        